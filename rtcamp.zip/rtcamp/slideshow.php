<?php
/*
Plugin Name: Rtcamp slideshow
Description: slideshow plugin.
Version: 1.0.0
Author: Prakash Chanpura
Author URI: #
*/

include( plugin_dir_path( __FILE__ ) . 'include/front.php');
include( plugin_dir_path( __FILE__ ) . 'include/setting.php');
include( plugin_dir_path( __FILE__ ) . 'include/ajax_action.php');

function create_tbl_slideshow()
{      
  global $wpdb; 
  $db_table_name = $wpdb->prefix . 'cp_slideshow';  // table name
  $charset_collate = $wpdb->get_charset_collate();
  $rt_db_version = '1.0.0';

  //Check to see if the table exists already, if not, then create it
  if($wpdb->get_var( "show tables like '$db_table_name'" ) != $db_table_name ) 
  {
       $sql = "CREATE TABLE $db_table_name (
            id int(11) NOT NULL auto_increment,
            img_name varchar(255) NOT NULL,
            img_order int(5) NOT NULL DEFAULT '0',
            created datetime NOT NULL,
            modified datetime NOT NULL,
            status enum('1','0') NOT NULL DEFAULT '1',
            PRIMARY KEY id (id)
        ) $charset_collate;";

      require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
      dbDelta( $sql );
      add_option( 'rt_db_version', $rt_db_version );
  }
} 

register_activation_hook( __FILE__, 'create_tbl_slideshow' );


