$(document).ready(function () {
    $('.reorder').on('click', function () {
        $("ul.nav").sortable({
            tolerance: 'pointer'
        });
        $('.reorder').html('Save Reordering');
        $('.reorder').attr("id", "updateReorder");
        $('#reorder-msg').slideDown('');
        $('.img-link').attr("href", "javascript:;");
        $('.img-link').css("cursor", "move");
        $("#updateReorder").click(function (e) {
            if (!$("#updateReorder i").length) {
                $(this).html('').prepend('Updating...');
                $("ul.nav").sortable('destroy');
                $("#reorder-msg").html("Reordering Photos - This could take a moment. Please don't navigate away from this page.").removeClass('light_box').addClass('notice notice_error');

                var h = [];
                $("ul.nav li").each(function () {
                    h.push($(this).attr('id').substr(9));
                });

                $.ajax({
                    type: "post",
                    url: ajaxurl,
                    //dataType: 'json',
                    data: {
                        action: 'rt_update_galary',
                        ids: h
                    },
                    success: function (response) {
                        if (response == 1 || parseInt(response) == 1) {
                            window.location.reload();
                        }
                    }
                });
                return false;
            }
            e.preventDefault();
        });
    });

    $(function () {
        $("#myDrop").sortable({
            items: '.dz-preview',
            cursor: 'move',
            opacity: 0.5,
            containment: '#myDrop',
            distance: 20,
            tolerance: 'pointer',
        });

        $("#myDrop").disableSelection();
    });

    //Dropzone script
    Dropzone.autoDiscover = false;

    var myDropzone = new Dropzone("div#myDrop", {
        paramName: "files", // The name that will be used to transfer the file
        addRemoveLinks: true,
        uploadMultiple: true,
        autoProcessQueue: false,
        parallelUploads: 50,
        maxFilesize: 5, // MB
        acceptedFiles: ".png, .jpeg, .jpg, .gif, .JPG, .JPEG, .PNG",
        url: ajaxurl,
    });

    myDropzone.on("sending", function (file, xhr, formData) {
        var filenames = [];

        $('.dz-preview .dz-filename').each(function () {
            filenames.push($(this).find('span').text());
        });

        formData.append('action', 'rt_save_galary');
        formData.append('filenames', filenames);
    });

    /* Add Files Script*/
    myDropzone.on("success", function (file, message) {
        if (message == 'successfully') {
            $("#msg").html('<div class="alert alert-success mt-3">Images uploaded successfully!</div>');

            setTimeout(function () {
                window.location.reload();
            }, 1000);
        } else {
            $("#msg").html('<div class="alert alert-warning mt-3">' + message + '</div>');
        }


    });

    myDropzone.on("error", function (data) {
        $("#msg").html('<div class="alert alert-danger">There is some thing wrong, Please try again!</div>');
    });

    myDropzone.on("complete", function (file) {
        myDropzone.removeFile(file);
    });

    $("#add_file").on("click", function () {
        myDropzone.processQueue();
    });

});

$(document).on('click','#delete_img',function(){
    var img_id = $(this).attr('fdi');
    $(this).parent().remove();
    $.ajax({
        type: "post",
        url: ajaxurl,
        //dataType: 'json',
        data: {
            action: 'rt_delete_galary',
            img_id: img_id
        },
        success: function (response) {
            
        }
    });
});