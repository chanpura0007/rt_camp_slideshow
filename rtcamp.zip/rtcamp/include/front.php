<?php 


function rtcamp_front_style() {
    wp_enqueue_style('custom-css',  WP_PLUGIN_URL .'/rtcamp/css/style.css', '', time());
    wp_enqueue_script('front_js',  WP_PLUGIN_URL .'/rtcamp/js/front_js.js', '', time());
}
add_action( 'wp_enqueue_scripts', 'rtcamp_front_style' );




function rt_camp_front_slideshow()
{
	global $wpdb;
    $db_table_name = $wpdb->prefix . 'cp_slideshow';
    $galary = $wpdb->get_results("SELECT * FROM $db_table_name ORDER BY img_order ASC");
    if($galary)
    {
    	echo '<div class="slideshow-container">';
    	foreach ($galary as $img) 
    	{
            echo '<div class="mySlides fade"><img src="'.WP_PLUGIN_URL .'/rtcamp/uploads/'.$img->img_name.'" style="width:100%"></div>';
    	}
    	echo '<a class="prev" onclick="plusSlides(-1)">❮</a><a class="next" onclick="plusSlides(1)">❯</a><div><br><div style="text-align:center"><span class="dot" onclick="currentSlide(1)"></span><span class="dot" onclick="currentSlide(2)"></span><span class="dot" onclick="currentSlide(3)"></span></div>';
    }

}
add_shortcode( 'rt_camp_slideshow', 'rt_camp_front_slideshow' );