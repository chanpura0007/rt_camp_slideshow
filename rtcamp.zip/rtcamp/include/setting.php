<?php 

// Add the admin menu
add_action('admin_menu', 'rtcamp_slider_menu');

function rtcamp_slider_menu() {
    add_menu_page(
        'SlideShow',
        'SlideShow',
        'manage_options',
        'rtcamp-slider',
        'rtcamp_slider_settings_page'
    );
}

function rtcamp_enqueued_assets($hook) {
	if ( isset( $_GET['page'] ) && $_GET['page'] == 'rtcamp-slider' ) {
    wp_enqueue_script('jquery-js',  WP_PLUGIN_URL .'/rtcamp/js/jquery.min.js', '', time());
    wp_enqueue_script('jquery-ui',  WP_PLUGIN_URL .'/rtcamp/js/jquery-ui.min.js', '', time());
    wp_enqueue_script('popper-js',  WP_PLUGIN_URL .'/rtcamp/js/popper.min.js', '', time());
    wp_enqueue_script('bootstrap-js',  WP_PLUGIN_URL .'/rtcamp/js/bootstrap.min.js', '', time());
    wp_enqueue_script('dropzone-js',  WP_PLUGIN_URL .'/rtcamp/js/dropzone.js', '', time());
    wp_enqueue_script('rt_camp-js',  WP_PLUGIN_URL .'/rtcamp/js/rt_camp.js', '', time());
    wp_enqueue_style('bootstrap-css',  WP_PLUGIN_URL .'/rtcamp/css/bootstrap.min.css', '', time());
    wp_enqueue_style('all-css',  WP_PLUGIN_URL .'/rtcamp/css/all.css', '', time());
    wp_enqueue_style('dropzone-css',  WP_PLUGIN_URL .'/rtcamp/css/dropzone.css', '', time());
    }      
}
add_action('admin_enqueue_scripts', 'rtcamp_enqueued_assets');
wp_localize_script( 'ajax_custom_script2', 'frontendajax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));
    

// Create the settings page
function rtcamp_slider_settings_page() 
{
	?>	
	<div class="container" style="margin-top: 40px;">
		<strong>Use shortcode : [rt_camp_slideshow] </strong>
		<div id="msg"></div>
	    <div class="dropzone dz-clickable" id="myDrop" style="min-height: 200px;">
	        <div class="dz-default dz-message" data-dz-message="">
	            <span>Drop files here to upload</span>
	        </div>
	    </div>
	    <input type="button" id="add_file" value="Add" class="btn btn-primary mt-3">
	</div>
	<hr class="my-5">
	<div class="container">
	    <a href="javascript:void(0);" class="btn btn-outline-primary reorder" id="updateReorder">Reorder Images</a>
	    <div id="reorder-msg" class="alert alert-warning mt-3" style="display:none;">1. Drag photos to reorder.<br>2. Click 'Save Reordering' when finished.
	    </div>
	    <div class="gallery">
	        <ul class="nav nav-pills">
	        	<?php 
	        	global $wpdb;
		        $db_table_name = $wpdb->prefix . 'cp_slideshow';
		        $galary = $wpdb->get_results("SELECT * FROM $db_table_name ORDER BY img_order ASC");
		        if($galary)
		        {
		        	foreach ($galary as $img) {
		        		?>
		        		<li id="image_li_<?php echo $img->id; ?>" class="ui-sortable-handle mr-2 mt-2">
			                <div><a href="javascript:void(0);" class="img-link"><img src="<?php echo WP_PLUGIN_URL .'/rtcamp/uploads/'.$img->img_name; ?>" alt="" class="img-thumbnail cp_img" width="200"></a></div>
			                <button class="btn btn-danger btn-sm width-100" fdi="<?php echo $img->id; ?>" id="delete_img">Delete</button>
			            </li>
		        		<?php
		        	}
		        }
	        	?>
	        </ul>
	    </div>
	</div>
	<?php
}