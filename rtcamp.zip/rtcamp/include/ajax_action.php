<?php
add_action('wp_ajax_rt_save_galary', 'rt_save_galary');
add_action('wp_ajax_nopriv_rt_save_galary', 'rt_save_galary'); 

add_action('wp_ajax_rt_update_galary', 'rt_update_galary');
add_action('wp_ajax_nopriv_rt_update_galary', 'rt_update_galary'); 

add_action('wp_ajax_rt_delete_galary', 'rt_delete_galary');
add_action('wp_ajax_nopriv_rt_delete_galary', 'rt_delete_galary');


function rt_delete_galary()
{
    $id = $_POST['img_id'];
    global $wpdb;
    $db_table_name = $wpdb->prefix . 'cp_slideshow';
    $wpdb->delete( $db_table_name, array('id' => $id));
}
function rt_update_galary()
{
    $count = 1;
    global $wpdb;
    $db_table_name = $wpdb->prefix . 'cp_slideshow';
    foreach ($_POST['ids'] as $id){     
        $wpdb->update($db_table_name, array('img_order' => $count), array( 'id'=>$id ));
        $count ++;
    }
    echo '1';
    wp_die();
}

function rt_save_galary()
{
    $n=0;
    $s=0;
    $prepareNames=array();
    foreach($_FILES['files']['name'] as $val)
    {
        $infoExt        =   getimagesize($_FILES['files']['tmp_name'][$n]);
        $s++;
        $filesName      =   str_replace(" ","",trim($_FILES['files']['name'][$n]));
        $files          =   explode(".",$filesName);
        $File_Ext       =   substr($_FILES['files']['name'][$n], strrpos($_FILES['files']['name'][$n],'.'));
         
        if($infoExt['mime'] == 'image/gif' || $infoExt['mime'] == 'image/jpeg' || $infoExt['mime'] == 'image/png')
        {
            $srcPath    =   WP_PLUGIN_DIR .'/rtcamp/uploads/';
            $fileName   =   $s.rand(0,999).time().$File_Ext;
            $path   =   trim($srcPath.$fileName);
            if(move_uploaded_file($_FILES['files']['tmp_name'][$n], $path))
            {
                $prepareNames[] .=  $fileName; 
                $Sflag      =   1; // success
            }else{
                $Sflag  = 2; // file not move to the destination
            }
        }
        else
        {
            $Sflag  = 3; //extension not valid
        }
        $n++;
    }
    if($Sflag==1){
        echo 'successfully';
    }else if($Sflag==2){
        echo 'File not move to the destination.';
    }else if($Sflag==3){
        echo 'File extension not good. Try with .PNG, .JPEG, .GIF, .JPG';
    }
    if(!empty($prepareNames)){
        $count  =   1;
        global $wpdb;
        $db_table_name = $wpdb->prefix . 'cp_slideshow';
        $post_id = $wpdb->get_results("SELECT img_order FROM $db_table_name ORDER BY img_order DESC LIMIT 1");
        if($post_id)
        {
            $count = ($post_id[0]->img_order+1);
        }
        
        foreach($prepareNames as $name){            
            $wpdb->insert($db_table_name, array(
                'img_name' => $name,
                'img_order' => $count++,
            ));
        }
    }
    wp_die();
}